In order to install the Healthy Eating Game Piece set for Reach you goal SnL you need to:

1. Have Reach your goal SnL installed
2. Extract the contents of this archive to  %PROGRAMDATA%\Reach your goal SnL\Game_Piece. You can delete the default Game Pieces if you wish.


Program Source Code: https://github.com/chribonn/Reach-your-goal-SnL
Executable: https://download.cnet.com/Reach-Your-Goal-SnL/3000-18516_4-78156440.html